<?php

namespace App\Controller\Invitation;

use App\Entity\Invitation;
use App\Repository\InvitationRepository;
use App\Service\DateService;
use App\Service\PhoneService;
use App\Service\SmsService;
use App\Service\TelegramService;
use App\Service\WhatsappService;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Serializer\Exception\ExceptionInterface;
use Symfony\Component\Serializer\Normalizer\NormalizerInterface;
use Twilio\Exceptions\ConfigurationException;
use Twilio\Exceptions\TwilioException;

class SendInvitationController extends AbstractController
{
    public function __construct(
        private readonly PhoneService  $phoneService,
        private readonly SmsService $smsService,
        private readonly InvitationRepository $invitationRepository,
        private readonly NormalizerInterface $normalizer,
        private readonly WhatsappService $whatsappService,
        private readonly TelegramService $telegramService,
        private readonly DateService $dateService,
    )
    {
    }

    /**
     * @throws ExceptionInterface
     * @throws \JsonException
     */
    public function __invoke(Request $request, Invitation $invitation): JsonResponse
    {
        $content = json_decode($request->getContent(), true, 512, JSON_THROW_ON_ERROR);
        $method = $content["method"] ?? null;

        $link = "https://kuuwaa.com/invitations/" . $invitation->getId();

        $message = "Bonjour " . $invitation->getCivility() . " " . $invitation->getName();
        $message .= ",\nVous êtes invité à l'évenement \"{$invitation->getEvent()->getName()}\" le " . $this->dateService->getFullDate($invitation->getEvent()->getDate(), true, true) . ".";
        $message .= "\n\nPour accéder à votre invitation, veuillez ouvrir le lien suivant.";
        $message .= "\n" . $link;
        $message .= "\n\nSi vous rencontrez des difficultés pour ouvrir le lien ou pour accéder à l'application KuuWaa, veuillez retenir le code d'invitation à 6 chiffres ({$invitation->getCode()}) et présentez-le lors de la vérification à l'entrée de l'événement.";

        $phoneNumber = $this->phoneService->format($invitation->getPhoneNumber());
        if ($method === "sms") {
            $this->smsService->send($phoneNumber, $message);
        } else if ($method === "wpp") {
            $to = "whatsapp:+$phoneNumber";
            $body = "$message\n\nCeci est un message automatique, veuillez ne pas y repondre.";
            try {
                $messageSid = $this->whatsappService->sendWhatsAppMessage($to, $body);
            } catch (ConfigurationException|TwilioException $e) {
                dd($e);
            }
        } else if ($message === "tel") {
            $body = "$message\n\nCeci est un message automatique, veuillez ne pas y repondre.";
            $this->telegramService->sendMessage($body);
        } else {
            // error
        }

        $invitation->setStatus("sent");
        $this->invitationRepository->save($invitation, true);

        $invitations = $this->invitationRepository->findByEvent($invitation->getEvent());
        $response = [
            'success'   => true,
            'invitations' => $this->normalizer->normalize($invitations, null, ['groups' => ['invitation:pRead']]),
            'message'   => "Invitation envoyée avec succès",
        ];

        return new JsonResponse($response, Response::HTTP_OK);
    }
}