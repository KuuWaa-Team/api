<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/api/event_categories' => [[['_route' => 'eventCategories', '_controller' => 'App\\Controller\\EventCategory\\GetEventCategoriesController', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\EventCategory', '_api_operation_name' => 'eventCategories'], null, ['GET' => 0], null, false, false, null]],
        '/api/event_packs' => [[['_route' => 'eventPacks', '_controller' => 'App\\Controller\\EventPack\\GetEventPackController', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\EventPack', '_api_operation_name' => 'eventPacks'], null, ['GET' => 0], null, false, false, null]],
        '/api/event-admins' => [[['_route' => 'addAdmin', '_controller' => 'App\\Controller\\EventAdmin\\AddAdminController', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Event\\EventAdmin', '_api_operation_name' => 'addAdmin'], null, ['POST' => 0], null, false, false, null]],
        '/api/features' => [[['_route' => 'features', '_controller' => 'App\\Controller\\EventPack\\GetFeaturesController', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Feature', '_api_operation_name' => 'features'], null, ['GET' => 0], null, false, false, null]],
        '/api/invitations' => [
            [['_route' => 'myInvitation', '_controller' => 'App\\Controller\\Invitation\\MyInvitationsController', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Invitation', '_api_operation_name' => 'myInvitation'], null, ['GET' => 0], null, false, false, null],
            [['_route' => 'addInvitation', '_controller' => 'App\\Controller\\Invitation\\AddInvitationController', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Invitation', '_api_operation_name' => 'addInvitation'], null, ['POST' => 0], null, false, false, null],
        ],
        '/api/login' => [[['_route' => '_api_/login_post', '_controller' => 'App\\Controller\\Auth\\LoginController', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\User', '_api_operation_name' => '_api_/login_post'], null, ['POST' => 0], null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/api(?'
                    .'|/\\.well\\-known/genid/([^/]++)(*:43)'
                    .'|(?:/(index)(?:\\.([^/]++))?)?(*:78)'
                    .'|/(?'
                        .'|docs(?:\\.([^/]++))?(*:108)'
                        .'|contexts/([^.]+)(?:\\.(jsonld))?(*:147)'
                        .'|e(?'
                            .'|rrors/([^/]++)(?'
                                .'|(*:176)'
                            .')'
                            .'|vent(?'
                                .'|s(?'
                                    .'|/([^/]++)(?'
                                        .'|/(?'
                                            .'|a(?'
                                                .'|dmins(*:221)'
                                                .'|ctive_event_pack(*:245)'
                                            .')'
                                            .'|invitations(*:265)'
                                            .'|tables(?'
                                                .'|(*:282)'
                                            .')'
                                            .'|beverages(*:300)'
                                        .')'
                                        .'|(*:309)'
                                    .')'
                                    .'|(?:\\.([^/]++))?(?'
                                        .'|(*:336)'
                                    .')'
                                    .'|/(?'
                                        .'|([^/]++)/image(*:363)'
                                        .'|([^/\\.]++)(?:\\.([^/]++))?(?'
                                            .'|(*:399)'
                                        .')'
                                    .')'
                                .')'
                                .'|_(?'
                                    .'|categories(?'
                                        .'|/([^/\\.]++)(?:\\.([^/]++))?(*:453)'
                                        .'|(?:\\.([^/]++))?(*:476)'
                                        .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                            .'|(*:513)'
                                        .')'
                                    .')'
                                    .'|packs(?'
                                        .'|/([^/\\.]++)(?:\\.([^/]++))?(*:557)'
                                        .'|(?:\\.([^/]++))?(*:580)'
                                        .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                            .'|(*:617)'
                                        .')'
                                    .')'
                                    .'|admins(?'
                                        .'|/([^/\\.]++)(?:\\.([^/]++))?(*:662)'
                                        .'|(?:\\.([^/]++))?(*:685)'
                                        .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                            .'|(*:722)'
                                        .')'
                                    .')'
                                .')'
                                .'|\\-admins/([^/]++)/(?'
                                    .'|accept(*:760)'
                                    .'|refuse(*:774)'
                                .')'
                            .')'
                        .')'
                        .'|validation_errors/([^/]++)(?'
                            .'|(*:814)'
                        .')'
                        .'|beverages(?'
                            .'|/([^/\\.]++)(?:\\.([^/]++))?(*:861)'
                            .'|(?:\\.([^/]++))?(*:884)'
                            .'|(*:892)'
                            .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                .'|(*:929)'
                            .')'
                        .')'
                        .'|features(?'
                            .'|/([^/\\.]++)(?:\\.([^/]++))?(*:976)'
                            .'|(?:\\.([^/]++))?(*:999)'
                            .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                .'|(*:1036)'
                            .')'
                        .')'
                        .'|invitations/(?'
                            .'|([^/\\.]++)(?:\\.([^/]++))?(*:1087)'
                            .'|check\\-code(*:1107)'
                            .'|([^/]++)/send(*:1129)'
                            .'|send\\-all(*:1147)'
                            .'|([^/\\.]++)(?:\\.([^/]++))?(?'
                                .'|(*:1184)'
                            .')'
                        .')'
                        .'|otps(?'
                            .'|/([^/\\.]++)(?:\\.([^/]++))?(*:1228)'
                            .'|(?:\\.([^/]++))?(*:1252)'
                            .'|/verification(*:1274)'
                        .')'
                        .'|tables(?'
                            .'|/([^/\\.]++)(?:\\.([^/]++))?(*:1319)'
                            .'|(?:\\.([^/]++))?(*:1343)'
                            .'|(*:1352)'
                            .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                .'|(*:1390)'
                            .')'
                        .')'
                        .'|users(?'
                            .'|/([^/\\.]++)(?:\\.([^/]++))?(*:1435)'
                            .'|(?:\\.([^/]++))?(*:1459)'
                            .'|/([^/]++)/complete\\-profile(*:1495)'
                        .')'
                    .')'
                .')'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:1535)'
                .'|/invitations/([^/]++)(*:1565)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        43 => [[['_route' => 'api_genid', '_controller' => 'api_platform.action.not_exposed', '_api_respond' => 'true'], ['id'], null, null, false, true, null]],
        78 => [[['_route' => 'api_entrypoint', '_controller' => 'api_platform.action.entrypoint', '_format' => '', '_api_respond' => 'true', 'index' => 'index'], ['index', '_format'], null, null, false, true, null]],
        108 => [[['_route' => 'api_doc', '_controller' => 'api_platform.action.documentation', '_format' => '', '_api_respond' => 'true'], ['_format'], null, null, false, true, null]],
        147 => [[['_route' => 'api_jsonld_context', '_controller' => 'api_platform.jsonld.action.context', '_format' => 'jsonld', '_api_respond' => 'true'], ['shortName', '_format'], null, null, false, true, null]],
        176 => [
            [['_route' => '_api_errors_problem', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'ApiPlatform\\State\\ApiResource\\Error', '_api_operation_name' => '_api_errors_problem'], ['status'], ['GET' => 0], null, false, true, null],
            [['_route' => '_api_errors_hydra', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'ApiPlatform\\State\\ApiResource\\Error', '_api_operation_name' => '_api_errors_hydra'], ['status'], ['GET' => 0], null, false, true, null],
            [['_route' => '_api_errors_jsonapi', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'ApiPlatform\\State\\ApiResource\\Error', '_api_operation_name' => '_api_errors_jsonapi'], ['status'], ['GET' => 0], null, false, true, null],
        ],
        221 => [[['_route' => 'userEventAdmins', '_controller' => 'App\\Controller\\Event\\ListingAdminsController', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Event', '_api_operation_name' => 'userEventAdmins'], ['id'], ['GET' => 0], null, false, false, null]],
        245 => [[['_route' => 'activePack', '_controller' => 'App\\Controller\\Event\\ActivePackEventController', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Event', '_api_operation_name' => 'activePack'], ['id'], ['POST' => 0], null, false, false, null]],
        265 => [[['_route' => 'userInvitations', '_controller' => 'App\\Controller\\Event\\ListingEventInvitationsController', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Event', '_api_operation_name' => 'userInvitations'], ['id'], ['GET' => 0], null, false, false, null]],
        282 => [
            [['_route' => 'userTables', '_controller' => 'App\\Controller\\Event\\ListingEventTablesController', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Event', '_api_operation_name' => 'userTables'], ['id'], ['GET' => 0], null, false, false, null],
            [['_route' => 'addTable', '_controller' => 'App\\Controller\\Event\\AddTableEventController', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Event', '_api_operation_name' => 'addTable'], ['id'], ['POST' => 0], null, false, false, null],
        ],
        300 => [[['_route' => 'userTBeverages', '_controller' => 'App\\Controller\\Event\\ListingEventBeveragesController', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Event', '_api_operation_name' => 'userTBeverages'], ['id'], ['GET' => 0], null, false, false, null]],
        309 => [
            [['_route' => 'eventDetail', '_controller' => 'App\\Controller\\Event\\EventDetailController', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Event', '_api_operation_name' => 'eventDetail'], ['id'], ['GET' => 0], null, false, true, null],
            [['_route' => 'editEvent', '_controller' => 'App\\Controller\\Event\\EditEventController', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Event', '_api_operation_name' => 'editEvent'], ['id'], ['POST' => 0], null, false, true, null],
        ],
        336 => [
            [['_route' => '_api_/events{._format}_get_collection', '_controller' => 'App\\Controller\\Event\\ListingUserEventController', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Event', '_api_operation_name' => '_api_/events{._format}_get_collection'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => '_api_/events{._format}_post', '_controller' => 'App\\Controller\\Event\\CreateEventController', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Event', '_api_operation_name' => '_api_/events{._format}_post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        363 => [[['_route' => '_api_/events/{id}/image_post', '_controller' => 'App\\Controller\\Event\\EditEventImageController', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Event', '_api_operation_name' => '_api_/events/{id}/image_post'], ['id'], ['POST' => 0], null, false, false, null]],
        399 => [
            [['_route' => '_api_/events/{id}{._format}_put', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Event', '_api_operation_name' => '_api_/events/{id}{._format}_put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => '_api_/events/{id}{._format}_delete', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Event', '_api_operation_name' => '_api_/events/{id}{._format}_delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
        ],
        453 => [[['_route' => '_api_/event_categories/{id}{._format}_get', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\EventCategory', '_api_operation_name' => '_api_/event_categories/{id}{._format}_get'], ['id', '_format'], ['GET' => 0], null, false, true, null]],
        476 => [[['_route' => '_api_/event_categories{._format}_post', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\EventCategory', '_api_operation_name' => '_api_/event_categories{._format}_post'], ['_format'], ['POST' => 0], null, false, true, null]],
        513 => [
            [['_route' => '_api_/event_categories/{id}{._format}_put', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\EventCategory', '_api_operation_name' => '_api_/event_categories/{id}{._format}_put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => '_api_/event_categories/{id}{._format}_delete', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\EventCategory', '_api_operation_name' => '_api_/event_categories/{id}{._format}_delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
        ],
        557 => [[['_route' => '_api_/event_packs/{id}{._format}_get', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\EventPack', '_api_operation_name' => '_api_/event_packs/{id}{._format}_get'], ['id', '_format'], ['GET' => 0], null, false, true, null]],
        580 => [[['_route' => '_api_/event_packs{._format}_post', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\EventPack', '_api_operation_name' => '_api_/event_packs{._format}_post'], ['_format'], ['POST' => 0], null, false, true, null]],
        617 => [
            [['_route' => '_api_/event_packs/{id}{._format}_put', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\EventPack', '_api_operation_name' => '_api_/event_packs/{id}{._format}_put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => '_api_/event_packs/{id}{._format}_delete', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\EventPack', '_api_operation_name' => '_api_/event_packs/{id}{._format}_delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
        ],
        662 => [[['_route' => '_api_/event_admins/{id}{._format}_get', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Event\\EventAdmin', '_api_operation_name' => '_api_/event_admins/{id}{._format}_get'], ['id', '_format'], ['GET' => 0], null, false, true, null]],
        685 => [[['_route' => '_api_/event_admins{._format}_get_collection', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Event\\EventAdmin', '_api_operation_name' => '_api_/event_admins{._format}_get_collection'], ['_format'], ['GET' => 0], null, false, true, null]],
        722 => [
            [['_route' => '_api_/event_admins/{id}{._format}_put', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Event\\EventAdmin', '_api_operation_name' => '_api_/event_admins/{id}{._format}_put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => '_api_/event_admins/{id}{._format}_delete', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Event\\EventAdmin', '_api_operation_name' => '_api_/event_admins/{id}{._format}_delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
        ],
        760 => [[['_route' => 'acceptInvitation', '_controller' => 'App\\Controller\\EventAdmin\\AcceptInvitationController', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Event\\EventAdmin', '_api_operation_name' => 'acceptInvitation'], ['id'], ['POST' => 0], null, false, false, null]],
        774 => [[['_route' => 'refuseInvitation', '_controller' => 'App\\Controller\\EventAdmin\\RefuseInvitationController', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Event\\EventAdmin', '_api_operation_name' => 'refuseInvitation'], ['id'], ['POST' => 0], null, false, false, null]],
        814 => [
            [['_route' => '_api_validation_errors_problem', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'ApiPlatform\\Symfony\\Validator\\Exception\\ValidationException', '_api_operation_name' => '_api_validation_errors_problem'], ['id'], ['GET' => 0], null, false, true, null],
            [['_route' => '_api_validation_errors_hydra', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'ApiPlatform\\Symfony\\Validator\\Exception\\ValidationException', '_api_operation_name' => '_api_validation_errors_hydra'], ['id'], ['GET' => 0], null, false, true, null],
            [['_route' => '_api_validation_errors_jsonapi', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'ApiPlatform\\Symfony\\Validator\\Exception\\ValidationException', '_api_operation_name' => '_api_validation_errors_jsonapi'], ['id'], ['GET' => 0], null, false, true, null],
        ],
        861 => [[['_route' => '_api_/beverages/{id}{._format}_get', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Beverage', '_api_operation_name' => '_api_/beverages/{id}{._format}_get'], ['id', '_format'], ['GET' => 0], null, false, true, null]],
        884 => [[['_route' => '_api_/beverages{._format}_get_collection', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Beverage', '_api_operation_name' => '_api_/beverages{._format}_get_collection'], ['_format'], ['GET' => 0], null, false, true, null]],
        892 => [[['_route' => 'addBeverage', '_controller' => 'App\\Controller\\Beverage\\AddBeverageController', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Beverage', '_api_operation_name' => 'addBeverage'], [], ['POST' => 0], null, false, false, null]],
        929 => [
            [['_route' => '_api_/beverages/{id}{._format}_put', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Beverage', '_api_operation_name' => '_api_/beverages/{id}{._format}_put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => '_api_/beverages/{id}{._format}_delete', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Beverage', '_api_operation_name' => '_api_/beverages/{id}{._format}_delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
        ],
        976 => [[['_route' => '_api_/features/{id}{._format}_get', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Feature', '_api_operation_name' => '_api_/features/{id}{._format}_get'], ['id', '_format'], ['GET' => 0], null, false, true, null]],
        999 => [[['_route' => '_api_/features{._format}_post', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Feature', '_api_operation_name' => '_api_/features{._format}_post'], ['_format'], ['POST' => 0], null, false, true, null]],
        1036 => [
            [['_route' => '_api_/features/{id}{._format}_put', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Feature', '_api_operation_name' => '_api_/features/{id}{._format}_put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => '_api_/features/{id}{._format}_delete', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Feature', '_api_operation_name' => '_api_/features/{id}{._format}_delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
        ],
        1087 => [[['_route' => '_api_/invitations/{id}{._format}_get', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Invitation', '_api_operation_name' => '_api_/invitations/{id}{._format}_get'], ['id', '_format'], ['GET' => 0], null, false, true, null]],
        1107 => [[['_route' => 'checkInvitationCode', '_controller' => 'App\\Controller\\Invitation\\CheckByCodeController', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Invitation', '_api_operation_name' => 'checkInvitationCode'], [], ['POST' => 0], null, false, false, null]],
        1129 => [[['_route' => 'sendInvitation', '_controller' => 'App\\Controller\\Invitation\\SendInvitationController', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Invitation', '_api_operation_name' => 'sendInvitation'], ['id'], ['POST' => 0], null, false, false, null]],
        1147 => [[['_route' => 'sendAllInvitation', '_controller' => 'App\\Controller\\Invitation\\SendAllController', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Invitation', '_api_operation_name' => 'sendAllInvitation'], [], ['POST' => 0], null, false, false, null]],
        1184 => [
            [['_route' => '_api_/invitations/{id}{._format}_put', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Invitation', '_api_operation_name' => '_api_/invitations/{id}{._format}_put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => '_api_/invitations/{id}{._format}_delete', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Invitation', '_api_operation_name' => '_api_/invitations/{id}{._format}_delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
        ],
        1228 => [[['_route' => '_api_/otps/{id}{._format}_get', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Otp', '_api_operation_name' => '_api_/otps/{id}{._format}_get'], ['id', '_format'], ['GET' => 0], null, false, true, null]],
        1252 => [[['_route' => '_api_/otps{._format}_get_collection', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Otp', '_api_operation_name' => '_api_/otps{._format}_get_collection'], ['_format'], ['GET' => 0], null, false, true, null]],
        1274 => [[['_route' => '_api_/otps/verification_post', '_controller' => 'App\\Controller\\Auth\\OtpVerificationController', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Otp', '_api_operation_name' => '_api_/otps/verification_post'], [], ['POST' => 0], null, false, false, null]],
        1319 => [[['_route' => '_api_/tables/{id}{._format}_get', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Table', '_api_operation_name' => '_api_/tables/{id}{._format}_get'], ['id', '_format'], ['GET' => 0], null, false, true, null]],
        1343 => [[['_route' => '_api_/tables{._format}_get_collection', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Table', '_api_operation_name' => '_api_/tables{._format}_get_collection'], ['_format'], ['GET' => 0], null, false, true, null]],
        1352 => [[['_route' => 'addTabble', '_controller' => 'App\\Controller\\Table\\AddTableController', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Table', '_api_operation_name' => 'addTabble'], [], ['POST' => 0], null, false, false, null]],
        1390 => [
            [['_route' => '_api_/tables/{id}{._format}_put', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Table', '_api_operation_name' => '_api_/tables/{id}{._format}_put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => '_api_/tables/{id}{._format}_delete', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\Table', '_api_operation_name' => '_api_/tables/{id}{._format}_delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
        ],
        1435 => [[['_route' => '_api_/users/{id}{._format}_get', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\User', '_api_operation_name' => '_api_/users/{id}{._format}_get'], ['id', '_format'], ['GET' => 0], null, false, true, null]],
        1459 => [[['_route' => '_api_/users{._format}_get_collection', '_controller' => 'api_platform.symfony.main_controller', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\User', '_api_operation_name' => '_api_/users{._format}_get_collection'], ['_format'], ['GET' => 0], null, false, true, null]],
        1495 => [[['_route' => '_api_/users/{id}/complete-profile_post', '_controller' => 'App\\Controller\\Auth\\CompleteProfileController', '_format' => null, '_stateless' => true, '_api_resource_class' => 'App\\Entity\\User', '_api_operation_name' => '_api_/users/{id}/complete-profile_post'], ['id'], ['POST' => 0], null, false, false, null]],
        1535 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        1565 => [
            [['_route' => 'app_public_invitation', '_controller' => 'App\\Controller\\Public\\InvitationController::index'], ['id'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
